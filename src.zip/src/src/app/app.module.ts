import { NgModule } from '@angular/core';
import { BrowserModule } from '@angular/platform-browser';
import { RouteReuseStrategy } from '@angular/router';

import { IonicModule, IonicRouteStrategy } from '@ionic/angular';
import { SplashScreen } from '@ionic-native/splash-screen/ngx';
import { StatusBar } from '@ionic-native/status-bar/ngx';


// all things related to firebase
import { environment } from 'src/environments/environment';
import * as firebase from 'firebase';
import {FormsModule,ReactiveFormsModule} from '@angular/forms';
import { AppComponent } from './app.component';
import { AppRoutingModule } from './app-routing.module';
import { AngularFireModule } from '@angular/fire';
import { AuthenticationService } from 'src/services/Authentication-Services.service';
import { AngularFirestoreModule } from '@angular/fire/firestore';
import {AngularFireAuth} from '@angular/fire/auth';
import { NgCalendarModule  } from 'ionic2-calendar';


firebase.initializeApp(environment.firebase);
@NgModule({
  declarations: [AppComponent],
  entryComponents: [],
  imports: [BrowserModule, IonicModule.forRoot(),
     AppRoutingModule,
     AngularFireModule.initializeApp(environment.firebase),
     ReactiveFormsModule,
    FormsModule,
    NgCalendarModule
    ],
  providers: [
    StatusBar,
    SplashScreen,
    AuthenticationService,
    AngularFirestoreModule,
    AngularFireAuth,
    { provide: RouteReuseStrategy, useClass: IonicRouteStrategy }
  ],
  bootstrap: [AppComponent]
})
export class AppModule {}
