import { Component, OnInit } from '@angular/core';
import { MenuController, NavController } from '@ionic/angular';
import { AuthenticationService } from 'src/services/Authentication-Services.service';
import * as firebase from 'firebase';
import { AngularFirestore } from '@angular/fire/firestore';
import { AngularFireAuth } from '@angular/fire/auth';
import { DataService, ApplyforLeave } from 'src/services/Data.service';
import { unescapeIdentifier } from '@angular/compiler';

@Component({
  selector: 'app-user-dashboard',
  templateUrl: './user-dashboard.page.html',
  styleUrls: ['./user-dashboard.page.scss'],
  providers:[DataService],
})
export class UserDashboardPage implements OnInit {

  constructor(
    private menuCtrl:MenuController,
    private navCtrl:NavController,
    private authService:AuthenticationService,
    public afstore:AngularFirestore,
    private fireAuth:AngularFireAuth,
    private profiles : DataService,
    private applicationProvider:DataService
  ) { }

  ngOnInit() {
  }


  items = [ 
    {
      name: 'Dashboard ',
      page: '/user-dashboard ',
      open :'',
      icon:'home'
    },
    {
    name : 'Leave Management',

   children : [
      
     {
       
         name: 'Apply for leave',
         page : '/apply-for-leave',
         icon: 'add-circle-outline'

     },

    
     { 
       name: 'Calendar',
       page: '/calendar/',
       icon: 'calendar'


     }

     

   ]

    }

  ];

Logout(){
  this.authService.LogoutUser()
  .then(res => {
    console.log(res);
    this.navCtrl.navigateBack('');
  })
  .catch(error => {
    console.log(error);
  })
}
}



