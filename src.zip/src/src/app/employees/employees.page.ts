import { Component, OnInit } from '@angular/core';
import { AngularFirestore } from '@angular/fire/firestore';
import { DataService } from 'src/services/Data.service';
import {Profile} from 'src/services/Data.service';
import { NavController } from '@ionic/angular';
import { AuthenticationService } from 'src/services/Authentication-Services.service';


@Component({
  selector: 'app-employees',
  templateUrl: './employees.page.html',
  styleUrls: ['./employees.page.scss'],
  providers : [DataService]
})
export class EmployeesPage implements OnInit {

  profiles : Profile [];
 
  // public ProfileList;

  constructor(
    public afstore:AngularFirestore,
    public profileprovider:DataService,
    private navCtrl:NavController,
     private authService:AuthenticationService,
     private data: DataService,
  ) { }

  ngOnInit() {

    this.getProfiles();
  }

  getProfiles() {

    this.profileprovider.getProfiles().subscribe(data => {
      this.profiles = data.map(e => {
        return {

          id: e.payload.doc.data()['id'],
          Name: e.payload.doc.data()['Name'],
          LastName:e.payload.doc.data()['LastName'],
          Company:e.payload.doc.data()['Company'],
          Phone:e.payload.doc.data()['Phone'],
          Password: e.payload.doc.data()['Password'],
          Email:e.payload.doc.data()['Email'],
          ConfirmPassword:e.payload.doc.data()['ConfirmPassword'],
          Admin_type:e.payload.doc.data()['Admin_type']

          
        } 
      });
    });

  }

  updateProfile(profiles:Profile) {
    this.profileprovider.updateProfiles(profiles);
  }

  deleteProfile(Email:string) {
    this.profileprovider.deleteProfile(Email);
  }



  items = [ 
    {
      name: 'Dashboard ',
      page: '/admin-dashboard ',
      open :'',
      icon:'home'
    },
    {
    name : 'Leave Management',

   children : [
        {
          name: ' Employees',
          page: '/employees',
          icon: 'people'

        },

     {
       
         name: 'Leave Type',
         page : '/leave-type',
         icon: 'code'

     },

   ]

    }

  ];

  Logout(){
    this.authService.LogoutUser()
    .then(res => {
      console.log(res);
      this.navCtrl.navigateBack('');
    })
    .catch(error => {
      console.log(error);
    })
  }

}
