import { Component, OnInit } from '@angular/core';
import { FormGroup, FormBuilder, FormControl, Validators } from '@angular/forms';
import { AuthenticationService } from 'src/services/Authentication-Services.service';
import 'firebase/auth';
import { NavController } from '@ionic/angular';
import { DataService } from 'src/services/Data.service';
import * as firebase from 'firebase';
import { AngularFirestore } from '@angular/fire/firestore';
import { ValueAccessor } from '@ionic/angular/directives/control-value-accessors/value-accessor';

@Component({
  selector: 'app-login',
  templateUrl: './login.page.html',
  styleUrls: ['./login.page.scss'],
})
export class LoginPage implements OnInit {

  validationform: FormGroup;
  errormessage: string = "";

 

  constructor(
    private formBuilder:FormBuilder,
    private navCtrl:NavController,
    private authService:AuthenticationService,
    public afstore:AngularFirestore,
  ) { }

  ngOnInit() {

    this.validationform = this.formBuilder.group({
      Email: new FormControl('', Validators.compose([
        Validators.required,
        Validators.pattern('^[a-zA-Z0-9_.+-]+@[a-zA-Z0-9-]+.[a-zA-Z0-9-.]+$')
      ])),
      Password: new FormControl('', Validators.compose([
        Validators.minLength(8),
        Validators.required
      ])),
    });
    

  }
  validation_messages = {
    'Email': [
      { type: 'required', message: 'Email is required.' },
      { type: 'pattern', message: 'Please enter a valid email.' }
    ],
    'Password': [
      { type: 'required', message: 'Password is required.' },
      { type: 'minlength', message: 'Password must be at least 8 characters long.' }
    ]
  };

  Login(value: { Email: string; Password: string;}){
    this.authService.LoginUser(value)
    .then(res => {
      console.log(res);
      this.errormessage = "";
      this.afstore.collection('Profile').ref.where("Email","==", value.Email).onSnapshot(snap => {
        snap.forEach(userRef => {
          console.log("userRef",userRef.data());
          if(userRef.data().Admin_type !== "Admin") {
            this.navCtrl.navigateForward('user-dashboard');
            }else 
            this.navCtrl.navigateForward('admin-dashboard');
          }, err => {
            this.errormessage = err.message;
      })
    })
  })
}

 /* LoginUser(value){
    this.authService.LoginUser(value)
    .then(res => {
      console.log(res);
      this.errormessage = "";
      this.navCtrl.navigateForward('admin-dashboard');
    }, err => {
      this.errormessage = err.message;
    })
  }
  */
  RegisterPage(){
    this.navCtrl.navigateForward('register');
  }
   
  ForgotPassword(){
    this.navCtrl.navigateForward('password-reset');
  }
    



}
