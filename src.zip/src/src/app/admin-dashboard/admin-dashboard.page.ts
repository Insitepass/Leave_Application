import { Component, OnInit } from '@angular/core';
import { DataService, ApplyforLeave } from 'src/services/Data.service';
import { NavController } from '@ionic/angular';
import { AuthenticationService } from 'src/services/Authentication-Services.service';
import { AngularFirestore } from '@angular/fire/firestore';

@Component({
  selector: 'app-admin-dashboard',
  templateUrl: './admin-dashboard.page.html',
  styleUrls: ['./admin-dashboard.page.scss'],
  providers:[DataService],
})
export class AdminDashboardPage implements OnInit {
 // array of application - type: applications
 applications: ApplyforLeave[];

 // application object - type: application
   application: ApplyforLeave;
 
    // toggleUpdateBtn variable is used to show/hide update button
    toggleUpdateBtn = false;
 
    dataUrl = 'assets/data/menus.json';
 
 
    showLevel1 = null;
    showLevel2 = null;
    showLevel3 = null;
   
    public appPages: any;
 
   constructor(
     private navCtrl:NavController,
     private authService:AuthenticationService,
     public afstore:AngularFirestore,
     private applicationProvider:DataService,
     private data: DataService,
    
     
     
   ) {}
   
     
 
   ngOnInit() {
       // we added getApplications() method in ngOnInit()
     // so that we get data to display over template - as soon as template loads.
    this.getApplications();
   /*  this.getMenus(); */
   }
   // this will return the  applications from the firebase store. 
 
   getApplications() {
        // we call getapplications from DataService to get list of applications
     this.applicationProvider.getApplications().subscribe(data => {
         // this.applications stores list of application
       this.applications = data.map(e => {
         return {
          id: e.payload.doc.id,
           Leave_startdate: e.payload.doc.data()['Leave_startdate'],
           Leave_enddate:e.payload.doc.data()['Leave_enddate'],
           Leave_Type:e.payload.doc.data()['Leave_Type'],
           Leave_days:e.payload.doc.data()['Leave_days'],
           Reason: e.payload.doc.data()['Reason'],
           Leave_status:e.payload.doc.data()['Leave_status'],
           
         } as ApplyforLeave;
       });
     });
   }
 
   updateApplication(Leave_Type:string){
     let doc = this.afstore.collection('Applications', ref=> ref.where('Leave_Type','==',Leave_Type));
     doc.snapshotChanges().subscribe((res: any) => {
       let id = res[0].payload.doc.id;
       this.afstore.collection('Applications').doc(id).update({Leave_Type: 'Approved'});
         
       });
    
   }
 
 
 
  
   items = [ 
     {
       name: 'Dashboard ',
       page: '/admin-dashboard ',
       open :'',
       icon:'home'
     },
     {
     name : 'Leave Management',
 
    children : [
         {
           name: ' Employees',
           page: '/employees',
           icon: 'people'
 
         },
 
      {
        
          name: 'Leave Type',
          page : '/leave-type',
          icon: 'code'
 
      },
 
    ]
 
     }
 
   ];
 
   Logout(){
     this.authService.LogoutUser()
     .then(res => {
       console.log(res);
       this.navCtrl.navigateBack('');
     })
     .catch(error => {
       console.log(error);
     })
   }
 }

