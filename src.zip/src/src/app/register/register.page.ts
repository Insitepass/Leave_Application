import { Component, OnInit } from '@angular/core';
import{ FormGroup,FormBuilder,Validators,FormControl} from '@angular/forms'
import{AuthenticationService} from 'src/services/Authentication-Services.service';
import {NavController} from '@ionic/angular';
import * as firebase from 'firebase';
import {Router} from '@angular/router';
import { DataService, Profile } from 'src/services/Data.service';
import {  AngularFirestore } from '@angular/fire/firestore';

@Component({
  selector: 'app-register',
  templateUrl: './register.page.html',
  styleUrls: ['./register.page.scss'],
  providers : [DataService]
})
export class RegisterPage implements OnInit {

  validations_form: FormGroup;
  errorMessage: string = '';
  successMessage: string = '';

  id: string = ""
  Name: string = ""
  LastName: string=""
  Email: string=""
  Company:string=""
  Phone:number 
  Password:string=""
  ConfirmPassword:string=""
  Admin_type: string=""


  constructor(
    private authService: AuthenticationService,
    public afstore:AngularFirestore,
    private router:Router,
    private navCtrl: NavController,
    private formBuilder: FormBuilder,
    public profile:DataService
  ) { }

  validation_messages = {
    'Email': [
      { type: 'required', message: 'Email is required.' },
      { type: 'pattern', message: 'Enter a valid email.' }
    ],
    'Password': [
      { type: 'required', message: 'Password is required.' },
      { type: 'minlength', message: 'Password must be at least 8 characters long.' }
    ],
    'ConfrimPassword': [
      {type: 'required',message:'Password do not match'}
    ],
    'Name': [
      { type: 'required', message:''}
    ],
    'LastName': [
      { type: 'required',message:''}
    ],
    'Company': [
      {
        type:'required', message:''
      }
    ],
    'Phone': [
      {
        type:'required',message:''
      }
    ],
    'Admin': [
      {
        type:'required',message:'please select user role'
      }
    ],
    'User':[
      {
        type:'required',message:'please select user role'
      }
    ]
  };

  ngOnInit() {
    this.validations_form = this.formBuilder.group({
      Email: new FormControl('', Validators.compose([
        Validators.required,
        Validators.pattern('^[a-zA-Z0-9_.+-]+@[a-zA-Z0-9-]+.[a-zA-Z0-9-.]+$')
      ])),
      Password: new FormControl('', Validators.compose([
        Validators.minLength(8),
        Validators.required
      ])),
      ConfirmPassword:new FormControl('',Validators.compose([
        Validators.minLength(8),
        Validators.required
      ])),
      Name: new FormControl('',Validators.compose([
      Validators.required
      ])),
      LastName: new FormControl('',Validators.compose([
        Validators.required
      ])),
      Company: new FormControl('',Validators.compose([
        Validators.required
      ])),
      Phone: new FormControl('',Validators.compose([
        Validators.required
      ])),
      'Admin_type':[null,Validators.required]
    });
    
  }

  Register(value: Profile){
    this.authService.RegisterUser(value)
     .then(res => {
       console.log(res);
       this.errorMessage = "";
       this.successMessage = "Your account has been created. Please log in.";
     }, err => {
       console.log(err);
       this.errorMessage = err.message;
       this.successMessage = "";
     })
     if (this.Password !== this.ConfirmPassword){
       alert('Passwords do not match');
       return;
     }
    this.afstore.collection('Profile').doc(this.afstore.createId()).set(value)
    this.profile.setProfile
    this.router.navigate(['/login/'+this.profile]),
     this.navCtrl.navigateBack('login');
}
goLoginPage(){
  this.navCtrl.navigateBack('login');
}
  }


