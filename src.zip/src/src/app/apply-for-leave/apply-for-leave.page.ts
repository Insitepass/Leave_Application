import { Component, OnInit } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';
import { NavController, AlertController } from '@ionic/angular';
import { FormBuilder, Validators, FormGroup } from '@angular/forms';
import { AngularFirestore } from '@angular/fire/firestore';
import * as firebase from 'firebase';
import { DataService, ApplyforLeave } from 'src/services/Data.service';



@Component({
  selector: 'app-apply-for-leave',
  templateUrl: './apply-for-leave.page.html',
  styleUrls: ['./apply-for-leave.page.scss'],
  providers:[DataService]
})

//const appl = new ApplyForLeavePage();
export class ApplyForLeavePage implements OnInit {

  Leave_status   :  string;
  infoForm: FormGroup;


  constructor(
    public route:ActivatedRoute,
    public router:Router,
    private navCtrl:NavController,
    private formBuilder:FormBuilder,
    public afstore:AngularFirestore,
    public alertController: AlertController,
  )
   { 

    this.infoForm = this.formBuilder.group({
      'Leave_startdate': [null,Validators.required],
      'Leave_enddate' : [null,Validators.required],
      'Leave_Type' : [null,Validators.required],
      'Leave_days' : [null,Validators.required],
      'Reason': [null,Validators.required],
       // this will be added as field in the firebase collection.
       'Leave_status':['Pedding'],
       
  });
}

  Apply() 
  {
    this.afstore.collection('Applications').doc(this.afstore.createId()).set(this.infoForm.value);
    this.presentAlert();
    this.navCtrl.navigateBack('user-dashboard');
 
 }
 submitform() {

   console.log(this.infoForm.value)
       }


       async presentAlert() {
        const alert = await this.alertController.create({
          cssClass: 'my-custom-class',
          header: 'Leave Requested Successfuly',
          message: 'Awaiting Aproval',
          buttons: ['OK']
        });
        await alert.present();
      }
       getDate(e){
         let date = new Date(e.target.value).toDateString().substring(0,10);
         this.infoForm.get('startdate').setValue(date,{
           onlyself:true
         })
         this.infoForm.get('enddate').setValue(date,{
           onlyself:true
         })
       }
       

   
 ngOnInit() {
 }

 items = [ 
   {
     name: 'Dashboard ',
     page: '/user-dashboard',
     open :'',
     icon:'home'
   },
   {
   name : 'Leave Management',

  children : [
     
    {
      
        name: 'Apply for leave',
        page : '/apply-for-leave',
        icon: 'add-circle-outline'

    },

   
    { 
      name: 'Calendar',
      page: '/calendar/',
      icon: 'calendar'


    }

    

  ]

   }

 ];

 gohome()
 {
   this.navCtrl.navigateBack('user-dashboard');
 }

}
