import { Injectable } from '@angular/core';
import * as firebase from 'firebase/app';
import { AngularFirestore } from '@angular/fire/firestore';
import { NavController } from '@ionic/angular';
         
    
    @Injectable({
      providedIn: 'root'
    })
    
    @Injectable()
    export class AuthenticationService {
      
     currentUser:any;
    
    constructor(
      public afstore:AngularFirestore,
      private navCtrl:NavController,
    ) {}
               
      ngOnInit(){
    
      }
    
      // Register method
    RegisterUser(value: { Email: string; Password: string; }){
      return new Promise<any>((resolve,reject) => {
          firebase.auth().createUserWithEmailAndPassword(value.Email, value.Password)
              .then(
              res => resolve(res),
              err => reject(err))
            })
            
    }
    
    
    // login User method
    LoginUser(value: { Email: string; Password: string; }){
      return new Promise<any>((resolve,reject)=> {
          firebase.auth().signInWithEmailAndPassword(value.Email,value.Password)
          .then(
              res => resolve(res),
              err => reject(err))
      })

      
    }
    // retrieve current user info.
    isLoggedIn() {
      return this.currentUser != null;
    }

  


    // logout user method
    LogoutUser(){
      return new Promise((resolve,reject) => {
          if(firebase.auth().currentUser){
              firebase.auth().signOut()
              .then(() => {
                  console.log("LOG OUT");
                  resolve();
              }).catch(() => {
                  reject();
              });
          }
      })
    }
    
    // ResetPassword function
    ResetPassword(email:string): Promise<void> {
      return firebase.auth().sendPasswordResetEmail(email);
    }
    
    // retrieve user details (email)
    userDetails(){
       return firebase.auth().currentUser;
    } 
    
    
    
    }