import 'firebase/firestore';
import { Injectable } from '@angular/core';
import { AngularFirestore } from '@angular/fire/firestore';
import * as firebase from 'firebase';
import { AuthenticationService } from './Authentication-Services.service';

import { map } from 'rxjs/operators';





export interface ApplyforLeave {
  
  Leave_startdate:string;
  Leave_enddate:string;
  Leave_Type:string;
  Leave_days:number;
  Reason: string
  Leave_status: 'Pendding';
  
    
  }


export interface Profile {

Name: string,
LastName:string,
Email: string,
Company:string,
Phone:number,
Password:string,
ConfirmPassword:string,
Admin_type:string


}



@Injectable()
export class DataService {

  private profile:Profile
  
 

  constructor(
    public afstore:AngularFirestore,
    private authService:AuthenticationService,
  
   
  
  ) {}

  // Applying for leave
  
  ApplyforLeave(value:{
    id : string,
    startdate:string,
    enddate:string,
    Typeofleave:string,
    Numberofdays:string,
    Reason: string,
    leave_type: string,
    Leave_Status:'string'
    
    }) {

      return firebase.firestore().collection('Applications').doc(this.afstore.createId()).set({
        value
      });

    }

  setProfile(profile:Profile) {

    this.profile = profile
  }

  getcurrentUser() {
    return this.afstore.collection('Profile').snapshotChanges();
    
  }


  getUid() {
    return this.profile.Name
  }
  // getting user profiles
  getProfiles() {
    return this.afstore.collection('Profile').snapshotChanges();
}

//update profile

updateProfiles(profiles:Profile)
{
  const profileObject = { profiles};
  this.afstore.doc('Profile/'+profiles.Email).update(profileObject);

}



deleteProfile(Email:string){
  this.afstore.doc('Profile/'+Email).delete()
}
/* getApplicationList(): AngularFirestoreCollection<ApplyforLeave>{
  return this.afstore.collection('Applications').snapshotChanges();
} */

// retrieves all the the applications from the firebase database.
getApplications() {
  return this.afstore.collection('Applications').snapshotChanges();
}


// updates the the leave_type field in the firebase collection.
updateApplication(Leave_Type:string){
  let doc = this.afstore.collection('Applications', ref=> ref.where('Leave_Type','==',Leave_Type));
  doc.snapshotChanges().subscribe((res: any) => {
    let id = res[0].payload.doc.id;
    this.afstore.collection('Applications').doc(id).update({Leave_Type: 'Approved'});
      
    });
}


/* updateApplication(application:ApplyforLeave) {
  this.afstore.doc('Applications').update({"Leave_Type": "Approved"})
} */




}



  
        


  
 